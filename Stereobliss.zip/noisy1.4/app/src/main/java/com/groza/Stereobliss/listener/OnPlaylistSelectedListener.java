/* */

package com.groza.Stereobliss.listener;

import com.groza.Stereobliss.models.PlaylistModel;

public interface OnPlaylistSelectedListener {
    void onPlaylistSelected(PlaylistModel playlistModel);
}
