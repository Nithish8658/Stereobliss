/* */

package com.groza.Stereobliss.artwork.storage;

public class ImageNotFoundException extends Exception {
}
