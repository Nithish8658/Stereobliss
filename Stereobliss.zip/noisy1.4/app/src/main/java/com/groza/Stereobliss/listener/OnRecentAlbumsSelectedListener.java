/* */

package com.groza.Stereobliss.listener;

public interface OnRecentAlbumsSelectedListener {
    void onRecentAlbumsSelected();
}
