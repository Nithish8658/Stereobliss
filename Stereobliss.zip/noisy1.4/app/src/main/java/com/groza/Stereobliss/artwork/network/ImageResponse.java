/* */

package com.groza.Stereobliss.artwork.network;

public class ImageResponse {
    public ArtworkRequestModel model;
    public String url;
    public byte[] image;
    public String localArtworkPath;
}
