/* */

package com.groza.Stereobliss.listener;

public interface OnStartSleepTimerListener {
    void onStartSleepTimer(long durationMS, boolean stopAfterCurrent);
}
