/* */

package com.groza.Stereobliss.viewitems;

import android.graphics.Bitmap;

public interface CoverLoadable {
    void setImage(Bitmap image);
}
