/* */

package com.groza.Stereobliss.listener;

public interface OnDirectorySelectedListener {
    void onDirectorySelected(String dirPath, boolean isRootDirectory);
}
