/* */

package com.groza.Stereobliss.dialogs;

import android.app.Dialog;
import android.os.Bundle;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import com.groza.Stereobliss.R;

public class LicensesDialog extends DialogFragment {

    public static LicensesDialog newInstance() {
        return new LicensesDialog();
    }

    /**
     * Create the dialog to show the third party licenses in a webview
     */
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        WebView view = new WebView(getActivity());
        view.loadUrl("file:///android_asset/thirdparty_licenses.html");
        return new MaterialAlertDialogBuilder(requireActivity())
                .setTitle(getString(R.string.odyssey_thirdparty_licenses_dialog_title))
                .setView(view)
                .setPositiveButton(android.R.string.ok, null)
                .create();
    }
}
